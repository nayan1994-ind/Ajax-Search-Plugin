<?php
/**
 * Plugin Name: AJAX Property Search
 * Plugin URI: https://weborbitsolutions.com
 * Description: This plugin will enable a Custom Post Type, Properties as well as, it will allow users to search using a cool AJAX method.
 * Version: 1.0.0
 * Author: Weborbit Solutions Private Limited
 * License: 
 */
/**
 * Register meta boxes.
 */

function hcf_register_meta_boxes() {
    add_meta_box( 'hcf-1', __( 'Search Fields', 'hcf' ), 'hcf_display_callback', 'Properties' );
}
add_action( 'add_meta_boxes', 'hcf_register_meta_boxes' );

/**
 * Meta box display callback.
 *
 * @param WP_Post $post Current post object.
 */
function hcf_display_callback( $post ) {
global $post;
$values = get_post_custom( $post->ID );

$selected_price = isset( $values['price_field'] ) ? esc_attr( $values['price_field'][0] ) : ”;
$storey = isset( $values['storey'] ) ? esc_attr( $values['storey'][0] ) : ”;

$bedroom = isset( $values['bedroom'] ) ? esc_attr( $values['bedroom'][0] ) : ”;
$bathroom = isset( $values['bathroom'] ) ? esc_attr( $values['bathroom'][0] ) : ”;
$lotsize = isset( $values['lotsize'] ) ? esc_attr( $values['lotsize'][0] ) : ”;
?>
<style scoped>
        .hcf_box{
            display: grid;
            grid-template-columns: max-content 1fr;
            grid-row-gap: 10px;
            grid-column-gap: 20px;
        }
        .hcf_field{
            display: inline-block;
        }
        .hcf_field_actual{
            display: contents;
        }
    </style>

    <div class="hcf_box">
    
   
    <p class="meta-options hcf_field">
        <label for="price">Price </label>
       
        <select id="price_field" name="price_field"> 
            <option value="100000" <?php selected( $selected_price, '100000' ); ?>>100000</option>
            <option value="150000" <?php selected( $selected_price, '150000' ); ?>>150000</option>
            <option value="200000" <?php selected( $selected_price, '200000' ); ?>>200000</option>
            <option value="250000" <?php selected( $selected_price, '250000' ); ?>>250000</option>
            <option value="300000" <?php selected( $selected_price, '300000' ); ?>>300000</option>
            <option value="350000" <?php selected( $selected_price, '350000' ); ?>>350000</option>
            <option value="400000" <?php selected( $selected_price, '400000' ); ?>>400000</option>
            <option value="450000" <?php selected( $selected_price, '450000' ); ?>>450000</option>
            <option value="500000" <?php selected( $selected_price, '500000' ); ?>>500000</option>
            <option value="550000" <?php selected( $selected_price, '550000' ); ?>>550000</option>
            <option value="600000" <?php selected( $selected_price, '600000' ); ?>>600000</option>
            <option value="650000" <?php selected( $selected_price, '650000' ); ?>>650000</option>
            <option value="700000" <?php selected( $selected_price, '700000' ); ?>>700000</option>
            <option value="750000" <?php selected( $selected_price, '750000' ); ?>>750000</option>
            <option value="800000" <?php selected( $selected_price, '800000' ); ?>>800000</option>
            <option value="850000" <?php selected( $selected_price, '850000' ); ?>>850000</option>
            <option value="900000" <?php selected( $selected_price, '900000' ); ?>>900000</option>
            <option value="950000" <?php selected( $selected_price, '950000' ); ?>>950000</option>
            <option value="1000000" <?php selected( $selected_price, '1000000' ); ?>>1000000</option>
            <option value="1100000" <?php selected( $selected_price, '1100000' ); ?>>1100000</option>
            <option value="1200000" <?php selected( $selected_price, '1200000' ); ?>>1200000</option>
            <option value="1300000" <?php selected( $selected_price, '1300000' ); ?>>1300000</option>
            <option value="1400000" <?php selected( $selected_price, '1400000' ); ?>>1400000</option>
            <option value="1500000" <?php selected( $selected_price, '1500000' ); ?>>1500000</option>
            <option value="1600000" <?php selected( $selected_price, '1600000' ); ?>>1600000</option>
            <option value="1700000" <?php selected( $selected_price, '1700000' ); ?>>1700000</option>
            <option value="1800000" <?php selected( $selected_price, '1800000' ); ?>>1800000</option>
            <option value="1900000" <?php selected( $selected_price, '1900000' ); ?>>1900000</option>
            <option value="2000000" <?php selected( $selected_price, '2000000' ); ?>>2000000</option>
        </select>
        
    </p>
    <p class="meta-options hcf_field">
        <label for="storey">Storeys </label>
        <input id="storey" type="radio" name="storey" value="1" <?php checked( $storey, '1' ); ?>>1
        <input id="storey" type="radio" name="storey" value="2" <?php checked( $storey, '2' ); ?>>2
    </p>
    <p class="meta-options hcf_field">
        <label for="bedrooms">Bedrooms </label>
        <input id="bedroom" type="radio" name="bedroom" value="2" <?php checked( $bedroom, '2' ); ?>>2
        <input id="bedroom" type="radio" name="bedroom" value="3" <?php checked( $bedroom, '3' ); ?>>3
        <input id="bedroom" type="radio" name="bedroom" value="4" <?php checked( $bedroom, '4' ); ?>>4
        <input id="bedroom" type="radio" name="bedroom" value="5" <?php checked( $bedroom, '5' ); ?>>5
    </p>
    <p class="meta-options hcf_field">
        <label for="bathroom">Bathroom </label>
        <input id="bathroom" type="radio" name="bathroom" value="1" <?php checked( $bathroom, '1' ); ?>>1
        <input id="bathroom" type="radio" name="bathroom" value="2" <?php checked( $bathroom, '2' ); ?>>2
        <input id="bathroom" type="radio" name="bathroom" value="3" <?php checked( $bathroom, '3' ); ?>>3
    </p>
    <p class="meta-options hcf_field">
        <label for="lot-size">Lot Width </label>
        <select id="lotsize" name="lotsize">
            <option value="7.5m to 8m" <?php selected( $lotsize, '7.5m to 8m' ); ?>>7.5m to 8m</option>
            <option value="8.5m to 9m" <?php selected( $lotsize, '8.5m to 9m' ); ?>>8.5m to 9m</option>
            <option value="9.5m to 10m" <?php selected( $lotsize, '9.5m to 10m' ); ?>>9.5m to 10m</option>
            <option value="10.5m to 11m" <?php selected( $lotsize, '10.5m to 11m' ); ?>>10.5m to 11m</option>
            <option value="11.5m to 12m" <?php selected( $lotsize, '11.5m to 12m' ); ?>>11.5m to 12m</option>
            <option value="12.5m to 13m" <?php selected( $lotsize, '12.5m to 13m' ); ?>>12.5m to 13m</option>
            <option value="13.5m to 14m" <?php selected( $lotsize, '13.5m to 14m' ); ?>>13.5m to 14m</option>
            <option value="14.5m to 15m" <?php selected( $lotsize, '14.5m to 15m' ); ?>>14.5m to 15m</option>
            <option value="15.5m to 16m" <?php selected( $lotsize, '15.5m to 16m' ); ?>>15.5m to 16m</option>
            <option value="16m+" <?php selected( $lotsize, '16m+' ); ?>>16m+</option>
        </select>
        
    </p>
    
</div>
<?php }

/**
 * Save meta box content.
 *
 * @param int $post_id Post ID
 */
function hcf_save_meta_box( $post_id ) {
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( $parent_id = wp_is_post_revision( $post_id ) ) {
        $post_id = $parent_id;
    }
    $fields = [
        'actual_price',
        'key_features',
        'price_field',
        'storey',
        'bedroom',
        'bathroom',
        'lotsize',
    ];
    foreach ( $fields as $field ) {
        if ( array_key_exists( $field, $_POST ) ) {
            update_post_meta( $post_id, $field, sanitize_text_field( $_POST[$field] ) );
        }
     }
}
add_action( 'save_post', 'hcf_save_meta_box' );




function cptui_register_my_cpts_properties() {

	/**
	 * Post Type: Properties.
	 */

	$labels = array(
		"name" => __( "Properties", "twentynineteen" ),
		"singular_name" => __( "Property", "twentynineteen" ),
	);

	$args = array(
		"label" => __( "Properties", "twentynineteen" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "properties", "with_front" => true ),
		"query_var" => true,
		"menu_icon" => "dashicons-admin-multisite",
		"supports" => array( "title", "editor", "thumbnail", "excerpt", "custom-fields", "comments", "author" ),
		"taxonomies" => array( "category", "post_tag" ),
	);

	register_post_type( "properties", $args );
}

add_action( 'init', 'cptui_register_my_cpts_properties' );



/*
Add Js In Footer section
*/

//Loading external style for loader in admin.
	function load_admin_styles() {
	    wp_enqueue_style( 'jquery_ui', plugin_dir_url( __FILE__ ) . 'css/jquery-ui.css');
		wp_enqueue_style( 'price_range_style', plugin_dir_url( __FILE__ ) . 'css/price_range_style.css');
		wp_enqueue_style('my-admin-theme', plugins_url('css/wp-admin.css', __FILE__));
		
	} 
add_action('wp_head', 'load_admin_styles');	
add_action("wp_footer", "pro_search_scripts");
 
function pro_search_scripts()
{
    wp_enqueue_script( 'my_custom_script1', plugin_dir_url( __FILE__ ) . 'js/jquery.min.js' );
    wp_enqueue_script( 'jquery_ui', plugin_dir_url( __FILE__ ) . 'js/jquery-ui.min.js' );
    wp_enqueue_script( 'my_custom_script', plugin_dir_url( __FILE__ ) . 'js/property-search.js' );
    wp_enqueue_script( 'price_range_script', plugin_dir_url( __FILE__ ) . 'js/price_range_script.js' );
    wp_localize_script('my_custom_script', 'ajax_url', admin_url( 'admin-ajax.php' ) );
	
}

function property_search(){
    pro_search_scripts();
 ob_start();

?>
<div id="property-search" class="property-srch">
  
   <?php include(plugin_dir_path( __FILE__ ) . 'form.php');?>
    </div>
<?php 
	return ob_get_clean();
}
add_shortcode('property_search', 'property_search');


add_action('wp_ajax_property_search' , 'pro_search_scripts_callback');
add_action('wp_ajax_nopriv_property_search' , 'pro_search_scripts_callback');
function pro_search_scripts_callback(){
    header('Content-type: application/json;');
    
   $minprice = 0;
    if(isset($_GET['min_price']))
    	$minprice = sanitize_text_field($_GET['min_price']);   
    	
    $maxprice = 0;
    if(isset($_GET['maxprice']))
    	$maxprice = sanitize_text_field($_GET['maxprice']);   

    $storeys = 0;
    if(isset($_GET['storey']))
    	$storey = sanitize_text_field($_GET['storey']);
    	
    $bedrooms = 0;
    if(isset($_GET['bedroom']))
    	$bedrooms = sanitize_text_field($_GET['bedroom']);
    	
    $bathrooms = 0;
    if(isset($_GET['bathroom']))
    	$bathrooms = sanitize_text_field($_GET['bathroom']);
    	
    $lotsize = 0;
    if(isset($_GET['lotsize']))
    	$lotsize = sanitize_text_field($_GET['lotsize']);	
    
     
     
    $result = array();
    $args = array(
    'post_type' => 'properties',
    'posts_per_page' => 10,
 );
$args['meta_query'][]=array(
    'relation' => 'OR',
    array(
        'key' => 'price_field',
        'value' =>$minprice,
        'compare' => ">="
    ),
    array(
        'key' => 'price_field',
        'value' =>$maxprice,
        'compare' => "<="
    ),
   
    array(
        'key' => 'storey',
        'value' =>$storey,
        'compare' => "IN"
    ),
    array(
            'key' => 'bedroom',
            'value' => $bedrooms,
            'compare' => "="
    ),
    array(
            'key' => 'bathroom',
            'value' =>$bathrooms,
            'compare' => "="
    ),
    array(
            'key' => 'lotsize',
            'value' =>$lotsize,
            'compare' => "="
    ),
); 

 
$the_querys = new WP_Query( $args );
    //print_r($the_querys->request);
    $posts_r = $the_querys->posts;
    foreach($posts_r as $post){
        $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'hh-gallery-2' );
        //$price = get_post_meta( $post->ID, 'actual_price') ;
        $storey = get_post_meta( $post->ID, 'storey') ;
        $beds_rooms_details = get_post_meta( $post->ID, 'bedroom') ;
        $bathrooms_details = get_post_meta( $post->ID, 'bathroom') ;
        array_push($result,array(
    	        "id" => $post->ID,
    			"title" => $post->post_title,
    			"permalink" => get_permalink($post),
    			"image_url" => $image[0],
    			"bedroom" => $beds_rooms_details ,
    			"bathroom" => $bathrooms_details,
    			"storey" => $storey,
    	));
    }
    
	if(count($result)>0){
        echo json_encode($result);
	}else{
	    echo 0;
	}
    wp_die();
}

add_action('admin_menu', 'add_global_custom_options');
function add_global_custom_options()  
{  
    add_options_page('Global Custom Options', 'Global Custom Options', 'manage_options', 'functions','global_custom_options');  
}



function global_custom_options()
{
?>
    <div class="wrap">
        <h2>Global Custom Options</h2>
        <form method="post" action="options.php">
            <?php wp_nonce_field('update-options') ?>
            <p><strong>Twitter ID:</strong><br />
                <textarea name="twitterid" style="height: 400px;width: 100%;"/><?php echo get_option('twitterid'); ?></textarea>
            </p>
            <p><input type="submit" name="Submit" value="Store Options" /></p>
            <input type="hidden" name="action" value="update" />
            <input type="hidden" name="page_options" value="twitterid" />
        </form>
    </div>
<?php
}



add_action('admin_head', 'my_custom_fonts');

function my_custom_fonts() {
  echo '<style>
    body, td, textarea, input, select {
      font-family: "Lucida Grande";
      font-size: 12px;
    } 
  </style>';
}
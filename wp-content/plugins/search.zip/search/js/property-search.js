$ = jQuery;


//var ajax_url = "<?php echo admin_url('admin-ajax.php'); ?>";
var proSearch = $("#property-search");/*Form Id*/
var searchForm = proSearch.find("form");
console.log('fgf');

$('.searchs,#price-range-submit').on('change',function (e){
   
    e.preventDefault();
  
    var data = {
         	action : "property_search", /*Function Name*/
            min_price : $('#min_price').val(),
            maxprice : $('#max_price').val(),
    	    storey :  $('input[name=storey]:checked').val(),
    	    bedroom : $('input[name=bedroom]:checked').val(),
    	    bathroom : $('input[name=bathroom]:checked').val(),
    	   lotsize : $('#lotsize').val(), 
	    
        };
       
        console.log(data);
         $.ajax({
        	url : ajax_url,/*define in functions page*/
        	data : data,
        	type : 'GET',
        	
        	success : function(response){
        	    console.log(response);
        	     if(response!==0){
        	       
            	    console.log(response);
            	   
            	    var html = '';
            	    for(var i=0; i<response.length; i++){
            			html = html+ "<div class='col_override'>" 
                    				+ "<div class='house_img_feature'>" 
                    			    + "<a href='" + response[i].permalink + "'>" + "<img src='" + response[i].image_url + "'+ 'alt='"+ response[i].title +"'>" + "</a>" 
                    			        + "<div class='house_info'>" 
                    			            + "<a href='" + response[i].permalink + "'>"+ response[i].title + "</a><span class='more-info'></span>" 
                    			                + "<div class='house_specs'>"
                    			                +"<div>"
                    			                +"<span class='icon_wrap'>Bedrooms <i class='fa fa-bed'></i> : " + response[i].bedroom+"</span><br>"
                    			                +"<span class='icon_wrap'>Bathrooms : <i class='fa fa-bath'></i>"+response[i].bathroom+"</span><br>"
                    			                +"<span class='icon_wrap'>Storey : <i class='fa fa-car'></i>"+response[i].storey+"</span><br>"
                    			                +"</div>"+
                    			               "</div>"+
                    			              "</div>"+
                    			         "</div>"+
                    			     "</div>";	  
                    			           
                         $("#datasearches").html(html);
                         $('.homes-loader').css("display","none");
                         $('.search1').css("display","none");
            
            		}
        	    }else{
        	        html = '';
        	       // console.log('No results found!');
        	        html= html + "No Result Found!";
        	         $("#datasearches").html(html);
        	         $('#datasearches').css({"text-align":"center","margin-bottom":"30px" ,"font-size":"16px"});
        	         $('.homes-loader').css("display","none");
        	         $('.search1').css("display","none");
        	        
        	    }
        	}
         });
        	  
});


                                                                                                                                
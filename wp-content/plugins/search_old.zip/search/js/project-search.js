$ = jQuery;
var projectSearch = $("#pro-id");/*Form Id*/
var searchForm = projectSearch.find("form");
var features_types='';
$('.search-button').click(function (e){
    e.preventDefault();
        $("#f-ser").hide();
        $('#y-ser').show();
        $('.search-again').show();
    	var data = {
     	action : "project_search", /*Function Name*/
    	//features_types : $('.dropdown-option:checked').map(function() {return this.value;}).get().join(','),/*form select field id*/
    	//features_types : $('.dropdown-option:checked').map(function(i, e) {return e.value}).toArray()
    	features_types : $("input[name='rd']:checked").val()
    };
    console.log(data);
    $.ajax({
	url : ajax_url,/*define in functions page*/
        	data : data,
        	type : 'GET',
            success : function(response){
        	    if(response!=0){
            	    console.log(response);
            	    var html = '';
            	    for(var i=0; i<response.length; i++){
            	   
                    html = html+ '<span data-post-id="project-' + response[i].id + '" class="single-project">' +
                        		'<div class="single-project-helper">' +
                        		    '<div class="image-here cover not-loaded dark-bg" data-src="'+ response[i].image_url +'" style="background-image: url('+ response[i].image_url +');"></div>' +
                        		        '<div class="single-project-title">' +
                        			        response[i].title + '<span class="single-project-title-hidden"><strong>×'+ response[i].key_1_values_service +'</strong></span>' +
                    			            '<div class="single-project-hover-stats flex">' +
                    			                '<div class="single-project-hover-single-stat">' +
                    				                response[i].key_2_values_area +' sq ft' +
                    			                '</div>' +
                                			   '<div class="single-project-hover-single-stat">' +
                                				  '$'+response[i].key_3_values_budget +
                                			   '</div>' +
                                			   '<div class="single-project-hover-single-stat">' +
                                				    response[i].key_4_values_sectors +
                                			   '</div>' +
                    			           '</div>' +
                        		        '</div>' +
                        		    '<div class="single-project-hover"></div>' +
                        		'</div>' +
                        	'</span>';
                        $("#datasearches").html(html);
            		}
        	    }else{
        	        html = '';
        	        console.log('No results found!');
        	        html= html + '<p style="text-align: center;">No results found!</p>';
        	         $("#datasearches").html(html);
        	       // $('.homes-loader').css("display","none");
        	    }
            }
    });
});
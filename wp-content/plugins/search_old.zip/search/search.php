<?php
/**
 * Plugin Name: Ajax Search
 * Plugin URI: 
 * Description: This plugin is use for search by ajax.
 * Version: 1.0.0
 * Author: WS
 * Author URI:
 * License: 
 */
 
class searchRooms{
    const ACF_VERSION_REQUIRED = '5.7.13';
	private $plugin_screen_name;

	public function __construct(){

		register_activation_hook(__FILE__, array($this, 'plugin_activate'));
		add_action('admin_enqueue_scripts', array($this,'load_admin_styles'));
		add_action('admin_menu', array($this, 'plugin_menu'));
        add_action('admin_footer',array($this,'socialproducts_ajax_script'));
	}
	
    //Upon plugin activation
    public function plugin_activate() {

	    $plugin_error = false;

	    if(file_exists(WP_PLUGIN_DIR.'/'.'advanced-custom-fields-pro/acf.php')){
	        $plugin_ext_data = get_plugin_data( WP_PLUGIN_DIR.'/'.'advanced-custom-fields-pro/acf.php');
	        $plugin_error = !version_compare ( $plugin_ext_data['Version'], self::ACF_VERSION_REQUIRED, '>=') ? true : false;
	    }else{
	    	$plugin_error = true;
	    }   

	    if ($plugin_error) {

	   // 	 echo '<div class="notice notice-error"><p>'.__('Please install <a target="_blank" href="https://www.advancedcustomfields.com/">Advanced Custom Fields</a> with a version >= 4.4.12', 'ap').'</p></div>';
	   // 	 exit;
	    	wp_die( __( 'Please install <a target="_blank" href="https://www.advancedcustomfields.com/">Advanced Custom Fields</a> with a version >= 5.7.13', 'ajax-search' ), 'Plugin dependency check', array( 'back_link' => true ) );

	    }else if (!is_plugin_active('advanced-custom-fields-pro/acf.php')){
					
			// Deactivate the plugin
			deactivate_plugins(__FILE__);
			
			//echo '<div class="notice notice-error"><p>'.__('Please activate <a target="_blank" href="https://www.advancedcustomfields.com/">Advanced Custom Fields</a> plugin before activating Social Products.', 'ap').'</p></div>';
			//exit;				
			wp_die( __( 'Please activate <a target="_blank" href="https://www.advancedcustomfields.com/">Advanced Custom Fields</a> before activating Social Products.', 'ajax-search' ), 'Plugin dependency check', array( 'back_link' => true ) );
		}
		else if(post_type_exists('homeandland') == false){
			include(plugin_dir_path( __FILE__ ) . 'register-homeandland.php');
		}
		
	
	}
    //Show menu on admin panel
    public function plugin_menu()
    {
	    $this->plugin_screen_name = add_menu_page(
		                                'Ajax Search',
		                                'Ajax Search',
		                                'manage_options',
		                                __FILE__, 
		                                array($this, 'ajaxsearch_render_page'), 
		                                'dashicons-download'
	                                );
	    $this->plugin_screen_name = add_submenu_page(__FILE__, 'Settings', 'Settings', 'manage_options', __FILE__, array($this,'ajaxsearch_render_settings_page'));
    }
    //Render settings page
    public function ajaxsearch_render_settings_page(){
	    include(plugin_dir_path( __FILE__ ) . 'render-settings.php');
    }

	//Add javascript to admin footer
	public function ajaxsearch_ajax_script() {
		echo '<script type="text/javascript">';
		include(plugin_dir_path( __FILE__ ) . '/js/project-search.js');
		echo '</script>';
	}
}
new searchRooms();